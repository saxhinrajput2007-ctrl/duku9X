import React from 'react';
import { Zap, User, LogOut, ShieldAlert, Home, LogIn, Sparkles, MessageSquare } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { ActivePage } from '../types';
import { FirebaseStatusBadge } from './FirebaseStatusBadge';

interface HeaderProps {
  activePage: ActivePage;
  onSelectPage: (page: ActivePage) => void;
  isMobileDeviceFrame: boolean;
  onToggleFrame: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activePage,
  onSelectPage,
  isMobileDeviceFrame,
  onToggleFrame,
}) => {
  const { user, signOut } = useAuth();

  return (
    <header className="sticky top-0 z-40 bg-zinc-950/90 backdrop-blur-md border-b border-purple-900/40 px-3 py-2.5 sm:px-4">
      <div className="max-w-6xl mx-auto flex items-center justify-between gap-2">
        {/* Brand Logo */}
        <div
          id="dukku-logo"
          onClick={() => onSelectPage('welcome')}
          className="flex items-center gap-2 cursor-pointer group"
        >
          <div className="relative flex items-center justify-center w-8 h-8 rounded-xl bg-gradient-to-br from-purple-600 via-purple-700 to-indigo-900 shadow-md shadow-purple-950 group-hover:scale-105 transition-transform">
            <Zap className="w-4 h-4 text-white fill-purple-300" />
            <div className="absolute -inset-0.5 rounded-xl bg-purple-500/20 blur-sm group-hover:bg-purple-500/40 transition-all -z-10" />
          </div>
          <div>
            <div className="flex items-center gap-1">
              <span className="font-extrabold tracking-tight text-white text-base sm:text-lg">
                Dukku
              </span>
              <span className="px-1.5 py-0.2 rounded bg-purple-900/80 text-purple-300 font-black text-xs border border-purple-600/50">
                9X
              </span>
            </div>
            <span className="hidden sm:block text-[10px] text-purple-400/80 tracking-widest uppercase -mt-1 font-semibold">
              Stranger Chat
            </span>
          </div>
        </div>

        {/* Center Nav Items */}
        <nav className="hidden md:flex items-center gap-1 bg-zinc-900/80 p-1 rounded-xl border border-purple-900/30">
          <button
            id="nav-chat-btn"
            onClick={() => onSelectPage('chat')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              activePage === 'chat'
                ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-md shadow-purple-950'
                : 'text-purple-300 hover:text-white hover:bg-purple-950/60'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5 text-purple-300" />
            <span>Stranger Chat</span>
          </button>
          <button
            id="nav-welcome-btn"
            onClick={() => onSelectPage('welcome')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              activePage === 'welcome'
                ? 'bg-purple-900/70 text-white border border-purple-600/50 shadow-sm'
                : 'text-zinc-400 hover:text-white hover:bg-zinc-800/60'
            }`}
          >
            Welcome
          </button>
          <button
            id="nav-login-btn"
            onClick={() => onSelectPage('login')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              activePage === 'login'
                ? 'bg-purple-900/70 text-white border border-purple-600/50 shadow-sm'
                : 'text-zinc-400 hover:text-white hover:bg-zinc-800/60'
            }`}
          >
            Login
          </button>
          <button
            id="nav-guest-btn"
            onClick={() => onSelectPage('guest')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              activePage === 'guest'
                ? 'bg-purple-900/70 text-white border border-purple-600/50 shadow-sm'
                : 'text-zinc-400 hover:text-white hover:bg-zinc-800/60'
            }`}
          >
            Guest
          </button>
          <button
            id="nav-home-btn"
            onClick={() => onSelectPage('home')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              activePage === 'home'
                ? 'bg-purple-900/70 text-white border border-purple-600/50 shadow-sm'
                : 'text-zinc-400 hover:text-white hover:bg-zinc-800/60'
            }`}
          >
            Dashboard
          </button>
        </nav>

        {/* Status Badge & Profile controls */}
        <div className="flex items-center gap-2">
          <FirebaseStatusBadge />

          {/* Device frame toggle for desktop testing */}
          <button
            id="toggle-device-frame-btn"
            onClick={onToggleFrame}
            title={isMobileDeviceFrame ? "Switch to Full View" : "Switch to Mobile Device Frame"}
            className="hidden lg:flex items-center gap-1 text-xs px-2.5 py-1 rounded-lg bg-zinc-900 border border-purple-900/40 text-purple-300 hover:bg-purple-950/60 hover:text-white transition-all"
          >
            <Sparkles className="w-3.5 h-3.5 text-purple-400" />
            <span>{isMobileDeviceFrame ? 'Full View' : 'Mobile View'}</span>
          </button>

          {user ? (
            <div className="flex items-center gap-1.5">
              <button
                id="header-user-profile-btn"
                onClick={() => onSelectPage('home')}
                className="flex items-center gap-2 px-2.5 py-1 rounded-xl bg-purple-950/60 border border-purple-700/50 text-white hover:bg-purple-900/60 transition-all"
              >
                {user.photoURL ? (
                  <img
                    src={user.photoURL}
                    alt="User"
                    className="w-5 h-5 rounded-full border border-purple-400/50"
                  />
                ) : (
                  <User className="w-4 h-4 text-purple-300" />
                )}
                <span className="text-xs font-medium max-w-[90px] truncate">
                  {user.displayName || (user.isAnonymous ? 'Guest' : 'User')}
                </span>
                {user.isAnonymous && (
                  <span className="text-[10px] bg-purple-900/90 text-purple-200 px-1 rounded font-bold">
                    GUEST
                  </span>
                )}
              </button>

              <button
                id="header-logout-btn"
                onClick={() => signOut()}
                title="Sign Out"
                className="p-1.5 rounded-lg bg-zinc-900 hover:bg-red-950/60 border border-purple-900/30 text-zinc-400 hover:text-red-300 transition-colors"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <button
              id="header-login-btn"
              onClick={() => onSelectPage('login')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-semibold shadow-md shadow-purple-950 transition-all"
            >
              <LogIn className="w-3.5 h-3.5" />
              <span>Login</span>
            </button>
          )}
        </div>
      </div>

      {/* Mobile Nav Bar */}
      <div className="flex md:hidden items-center justify-around mt-2 pt-2 border-t border-purple-950/60">
        <button
          id="mob-nav-chat"
          onClick={() => onSelectPage('chat')}
          className={`flex flex-col items-center text-[10px] font-medium gap-0.5 ${
            activePage === 'chat' ? 'text-purple-400 font-bold' : 'text-zinc-400'
          }`}
        >
          <MessageSquare className="w-4 h-4" />
          Chat
        </button>
        <button
          id="mob-nav-welcome"
          onClick={() => onSelectPage('welcome')}
          className={`flex flex-col items-center text-[10px] font-medium gap-0.5 ${
            activePage === 'welcome' ? 'text-purple-400 font-bold' : 'text-zinc-400'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          Welcome
        </button>
        <button
          id="mob-nav-login"
          onClick={() => onSelectPage('login')}
          className={`flex flex-col items-center text-[10px] font-medium gap-0.5 ${
            activePage === 'login' ? 'text-purple-400 font-bold' : 'text-zinc-400'
          }`}
        >
          <LogIn className="w-4 h-4" />
          Login
        </button>
        <button
          id="mob-nav-guest"
          onClick={() => onSelectPage('guest')}
          className={`flex flex-col items-center text-[10px] font-medium gap-0.5 ${
            activePage === 'guest' ? 'text-purple-400 font-bold' : 'text-zinc-400'
          }`}
        >
          <ShieldAlert className="w-4 h-4" />
          Guest
        </button>
        <button
          id="mob-nav-home"
          onClick={() => onSelectPage('home')}
          className={`flex flex-col items-center text-[10px] font-medium gap-0.5 ${
            activePage === 'home' ? 'text-purple-400 font-bold' : 'text-zinc-400'
          }`}
        >
          <Home className="w-4 h-4" />
          Dashboard
        </button>
      </div>
    </header>
  );
};
