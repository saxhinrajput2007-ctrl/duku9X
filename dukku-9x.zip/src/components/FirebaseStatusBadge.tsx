import React, { useState } from 'react';
import { ShieldCheck, Info, Database, HardDrive, Key, Globe, X, CheckCircle2 } from 'lucide-react';
import { isFirebaseConfigured } from '../lib/firebase';

export const FirebaseStatusBadge: React.FC = () => {
  const [showModal, setShowModal] = useState(false);

  return (
    <>
      <button
        id="firebase-status-badge-btn"
        onClick={() => setShowModal(true)}
        className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-purple-950/60 border border-purple-700/50 text-purple-300 hover:bg-purple-900/60 transition-all cursor-pointer shadow-sm shadow-purple-950"
      >
        <span className="relative flex h-2 w-2">
          <span
            className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
              isFirebaseConfigured ? 'bg-emerald-400' : 'bg-purple-400'
            }`}
          ></span>
          <span
            className={`relative inline-flex rounded-full h-2 w-2 ${
              isFirebaseConfigured ? 'bg-emerald-500' : 'bg-purple-500'
            }`}
          ></span>
        </span>
        <span className="truncate">
          {isFirebaseConfigured ? 'Firebase Cloud' : 'Local Demo Mode'}
        </span>
        <Info className="w-3 h-3 text-purple-400 ml-0.5" />
      </button>

      {showModal && (
        <div
          id="firebase-status-modal"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in"
        >
          <div className="bg-zinc-950 border border-purple-800/60 rounded-2xl p-6 max-w-md w-full shadow-2xl shadow-purple-950/50 text-zinc-100 relative">
            <button
              id="close-status-modal-btn"
              onClick={() => setShowModal(false)}
              className="absolute top-4 right-4 text-zinc-400 hover:text-white p-1 rounded-lg hover:bg-purple-900/30 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-4">
              <div className="p-2.5 rounded-xl bg-purple-900/40 border border-purple-700/50 text-purple-300">
                <ShieldCheck className="w-6 h-6 text-purple-400" />
              </div>
              <div>
                <h3 className="font-semibold text-lg text-white">Dukku 9X Firebase Setup</h3>
                <p className="text-xs text-purple-300/80">Project configuration diagnostics</p>
              </div>
            </div>

            <div className="space-y-3 my-5 text-sm">
              <div className="p-3 rounded-xl bg-purple-950/30 border border-purple-900/50 flex items-center justify-between">
                <div className="flex items-center gap-2 text-zinc-300">
                  <Key className="w-4 h-4 text-purple-400" />
                  <span>Firebase Auth</span>
                </div>
                <span className="flex items-center gap-1 text-xs text-emerald-400 font-medium">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Active
                </span>
              </div>

              <div className="p-3 rounded-xl bg-purple-950/30 border border-purple-900/50 flex items-center justify-between">
                <div className="flex items-center gap-2 text-zinc-300">
                  <Database className="w-4 h-4 text-purple-400" />
                  <span>Cloud Firestore</span>
                </div>
                <span className="flex items-center gap-1 text-xs text-emerald-400 font-medium">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Active
                </span>
              </div>

              <div className="p-3 rounded-xl bg-purple-950/30 border border-purple-900/50 flex items-center justify-between">
                <div className="flex items-center gap-2 text-zinc-300">
                  <HardDrive className="w-4 h-4 text-purple-400" />
                  <span>Firebase Storage</span>
                </div>
                <span className="flex items-center gap-1 text-xs text-emerald-400 font-medium">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Active
                </span>
              </div>

              <div className="p-3 rounded-xl bg-purple-950/30 border border-purple-900/50 flex items-center justify-between">
                <div className="flex items-center gap-2 text-zinc-300">
                  <Globe className="w-4 h-4 text-purple-400" />
                  <span>Firebase Hosting Config</span>
                </div>
                <span className="flex items-center gap-1 text-xs text-emerald-400 font-medium">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Configured
                </span>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-purple-950/50 border border-purple-800/40 text-xs text-purple-200/90 leading-relaxed">
              {isFirebaseConfigured ? (
                <span>Connected to live Firebase Cloud project. All auth tokens and document synchronization are processed on Firebase servers.</span>
              ) : (
                <span>Operating in smart local state mode with full auth simulation. Add your Firebase credentials in <code className="text-purple-300 bg-purple-900/60 px-1 rounded">.env</code> to connect live cloud backend.</span>
              )}
            </div>

            <button
              id="close-status-modal-action"
              onClick={() => setShowModal(false)}
              className="mt-5 w-full py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-medium text-sm hover:from-purple-500 hover:to-indigo-500 transition-all"
            >
              Close Diagnostics
            </button>
          </div>
        </div>
      )}
    </>
  );
};
