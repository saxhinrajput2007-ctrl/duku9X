import React from 'react';
import { Wifi, Battery, Signal } from 'lucide-react';

interface MobileFrameProps {
  children: React.ReactNode;
  isMobileDeviceFrame: boolean;
}

export const MobileFrame: React.FC<MobileFrameProps> = ({ children, isMobileDeviceFrame }) => {
  if (!isMobileDeviceFrame) {
    return <div className="min-h-screen bg-black text-zinc-100">{children}</div>;
  }

  return (
    <div className="min-h-screen bg-zinc-950 py-4 sm:py-8 px-2 sm:px-4 flex items-center justify-center">
      <div className="w-full max-w-[430px] min-h-[820px] bg-black border-4 border-purple-900/60 rounded-[48px] shadow-2xl shadow-purple-950/80 overflow-hidden relative flex flex-col my-auto">
        {/* Dynamic Island / Mobile Notch Header */}
        <div className="bg-zinc-950 px-6 pt-3 pb-2 flex items-center justify-between text-zinc-400 text-[11px] font-medium select-none z-50 border-b border-purple-950">
          <span>9:41</span>
          <div className="w-24 h-4 bg-black rounded-full border border-purple-900/40 mx-auto -mt-1 flex items-center justify-center">
            <div className="w-2.5 h-2.5 rounded-full bg-purple-900/80 mr-1" />
          </div>
          <div className="flex items-center gap-1.5 text-purple-300">
            <Signal className="w-3 h-3" />
            <Wifi className="w-3 h-3" />
            <Battery className="w-3.5 h-3.5" />
          </div>
        </div>

        {/* Device Content Viewport */}
        <div className="flex-1 overflow-y-auto custom-scrollbar flex flex-col">
          {children}
        </div>

        {/* Mobile Home Bar */}
        <div className="bg-zinc-950 py-2 flex items-center justify-center z-50 border-t border-purple-950">
          <div className="w-32 h-1 bg-purple-800/60 rounded-full" />
        </div>
      </div>
    </div>
  );
};
