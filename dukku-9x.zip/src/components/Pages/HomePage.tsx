import React, { useState, useEffect } from 'react';
import {
  User,
  Database,
  HardDrive,
  Globe,
  Plus,
  Trash2,
  Upload,
  CheckCircle2,
  Sparkles,
  ShieldAlert,
  Loader2,
  FileText,
  Clock,
  Layers,
  ExternalLink
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { firestoreService, storageService, isFirebaseConfigured } from '../../lib/firebase';
import { FirestoreDemoItem, StorageDemoFile, ActivePage } from '../../types';

interface HomePageProps {
  onNavigate: (page: ActivePage) => void;
}

export const HomePage: React.FC<HomePageProps> = ({ onNavigate }) => {
  const { user } = useAuth();

  // Firestore state
  const [items, setItems] = useState<FirestoreDemoItem[]>([]);
  const [itemTitle, setItemTitle] = useState('');
  const [itemCategory, setItemCategory] = useState('Project Task');
  const [loadingItems, setLoadingItems] = useState(true);
  const [addingItem, setAddingItem] = useState(false);

  // Storage state
  const [files, setFiles] = useState<StorageDemoFile[]>([]);
  const [uploadingFile, setUploadingFile] = useState(false);
  const [dragActive, setDragActive] = useState(false);

  // Fetch Firestore documents & Storage files
  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoadingItems(true);
    try {
      const [fetchedItems, fetchedFiles] = await Promise.all([
        firestoreService.getItems(),
        storageService.getFiles(),
      ]);
      setItems(fetchedItems);
      setFiles(fetchedFiles);
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingItems(false);
    }
  };

  const handleAddItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!itemTitle.trim()) return;

    setAddingItem(true);
    try {
      const createdBy = user?.displayName || (user?.isAnonymous ? 'Guest User' : 'Developer');
      const newItem = await firestoreService.addItem(
        itemTitle.trim(),
        itemCategory,
        createdBy,
        Boolean(user?.isAnonymous)
      );
      setItems((prev) => [newItem, ...prev]);
      setItemTitle('');
    } catch (err) {
      console.error(err);
    } finally {
      setAddingItem(false);
    }
  };

  const handleDeleteItem = async (id: string) => {
    try {
      await firestoreService.deleteItem(id);
      setItems((prev) => prev.filter((i) => i.id !== id));
    } catch (err) {
      console.error(err);
    }
  };

  const handleFileUpload = async (fileList: FileList | null) => {
    if (!fileList || fileList.length === 0) return;

    setUploadingFile(true);
    try {
      const uploadedBy = user?.displayName || (user?.isAnonymous ? 'Guest User' : 'Developer');
      const file = fileList[0];
      const uploaded = await storageService.uploadFile(file, uploadedBy);
      setFiles((prev) => [uploaded, ...prev]);
    } catch (err) {
      console.error(err);
    } finally {
      setUploadingFile(false);
    }
  };

  return (
    <div className="space-y-6 pb-12 animate-fade-in">
      {/* User Profile / Auth Session Card */}
      <div className="p-5 sm:p-6 rounded-3xl bg-zinc-950/90 border border-purple-800/50 shadow-xl shadow-purple-950/40 relative overflow-hidden">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            {user?.photoURL ? (
              <img
                src={user.photoURL}
                alt="Avatar"
                className="w-12 h-12 rounded-2xl border-2 border-purple-500/60 shadow-md shadow-purple-950"
              />
            ) : (
              <div className="w-12 h-12 rounded-2xl bg-purple-900/50 border border-purple-600/50 flex items-center justify-center text-purple-300">
                <User className="w-6 h-6" />
              </div>
            )}

            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-white">
                  {user ? user.displayName || 'Authenticated User' : 'Not Authenticated'}
                </h2>
                {user?.isAnonymous && (
                  <span className="px-2 py-0.5 rounded-full bg-purple-900/80 border border-purple-600/60 text-purple-200 text-[10px] font-bold">
                    GUEST TOKEN
                  </span>
                )}
              </div>
              <p className="text-xs text-purple-300/80 font-mono mt-0.5">
                {user ? user.email || `UID: ${user.uid}` : 'Sign in to sync Cloud Firestore & Storage'}
              </p>
            </div>
          </div>

          {!user && (
            <button
              id="home-login-prompt-btn"
              onClick={() => onNavigate('login')}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 text-white text-xs font-bold shadow-lg shadow-purple-950"
            >
              Authenticate Account
            </button>
          )}
        </div>
      </div>

      {/* Cloud Firestore Collection Tester */}
      <div className="p-5 sm:p-6 rounded-3xl bg-zinc-950/90 border border-purple-800/50 shadow-xl shadow-purple-950/40 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-purple-900/40">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-purple-900/40 border border-purple-700/50 text-purple-300">
              <Database className="w-5 h-5 text-purple-400" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white">Cloud Firestore Live Documents</h3>
              <p className="text-xs text-purple-300/80">Collection: <code className="text-purple-300 bg-purple-900/50 px-1 rounded">dukku_items</code></p>
            </div>
          </div>
          <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-purple-950 border border-purple-800 text-purple-300">
            {items.length} Docs
          </span>
        </div>

        {/* Add Document Form */}
        <form onSubmit={handleAddItem} className="flex flex-col sm:flex-row gap-2">
          <input
            id="firestore-item-title-input"
            type="text"
            placeholder="Add new document title..."
            value={itemTitle}
            onChange={(e) => setItemTitle(e.target.value)}
            className="flex-1 px-4 py-2.5 rounded-xl bg-zinc-900/80 border border-purple-900/50 text-white text-sm focus:outline-none focus:border-purple-500"
          />
          <select
            id="firestore-category-select"
            value={itemCategory}
            onChange={(e) => setItemCategory(e.target.value)}
            className="px-3 py-2.5 rounded-xl bg-zinc-900/80 border border-purple-900/50 text-purple-200 text-xs focus:outline-none focus:border-purple-500"
          >
            <option value="Project Task">Project Task</option>
            <option value="System">System</option>
            <option value="Database">Database</option>
            <option value="User Note">User Note</option>
          </select>
          <button
            id="firestore-add-doc-btn"
            type="submit"
            disabled={addingItem || !itemTitle.trim()}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-bold flex items-center justify-center gap-1.5 transition-all disabled:opacity-50 cursor-pointer"
          >
            {addingItem ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <>
                <Plus className="w-4 h-4" />
                <span>Write Document</span>
              </>
            )}
          </button>
        </form>

        {/* Document List */}
        {loadingItems ? (
          <div className="py-8 text-center text-xs text-purple-300/80 flex items-center justify-center gap-2">
            <Loader2 className="w-4 h-4 animate-spin text-purple-400" />
            <span>Loading Cloud Firestore items...</span>
          </div>
        ) : items.length === 0 ? (
          <div className="py-8 text-center text-xs text-zinc-500 border border-dashed border-purple-900/40 rounded-2xl">
            No documents found in Firestore collection. Add one above!
          </div>
        ) : (
          <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
            {items.map((item) => (
              <div
                key={item.id}
                className="p-3 rounded-2xl bg-zinc-900/70 border border-purple-900/40 flex items-center justify-between gap-3 hover:border-purple-700/50 transition-colors"
              >
                <div className="flex items-center gap-3 overflow-hidden">
                  <div className="p-2 rounded-lg bg-purple-950 text-purple-400 shrink-0">
                    <FileText className="w-4 h-4" />
                  </div>
                  <div className="overflow-hidden">
                    <div className="flex items-center gap-2">
                      <h4 className="text-xs font-bold text-white truncate">{item.title}</h4>
                      <span className="text-[10px] px-2 py-0.2 rounded bg-purple-900/60 text-purple-300 border border-purple-700/40">
                        {item.category}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-[10px] text-zinc-400 mt-0.5">
                      <span>By: {item.createdBy}</span>
                      <span>•</span>
                      <span>{new Date(item.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                    </div>
                  </div>
                </div>

                <button
                  id={`delete-firestore-item-${item.id}`}
                  onClick={() => handleDeleteItem(item.id)}
                  className="p-1.5 rounded-lg text-zinc-500 hover:text-red-400 hover:bg-red-950/40 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Firebase Storage File Uploader Tester */}
      <div className="p-5 sm:p-6 rounded-3xl bg-zinc-950/90 border border-purple-800/50 shadow-xl shadow-purple-950/40 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-purple-900/40">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-purple-900/40 border border-purple-700/50 text-purple-300">
              <HardDrive className="w-5 h-5 text-purple-400" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white">Firebase Storage Uploader</h3>
              <p className="text-xs text-purple-300/80">Bucket ref: <code className="text-purple-300 bg-purple-900/50 px-1 rounded">dukku_uploads/</code></p>
            </div>
          </div>
        </div>

        {/* Upload dropzone */}
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setDragActive(true);
          }}
          onDragLeave={() => setDragActive(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragActive(false);
            handleFileUpload(e.dataTransfer.files);
          }}
          className={`p-6 border-2 border-dashed rounded-2xl text-center transition-all ${
            dragActive
              ? 'border-purple-500 bg-purple-950/40'
              : 'border-purple-900/50 bg-zinc-900/50 hover:border-purple-700/60'
          }`}
        >
          <input
            id="storage-file-input"
            type="file"
            onChange={(e) => handleFileUpload(e.target.files)}
            className="hidden"
          />
          <label
            htmlFor="storage-file-input"
            className="cursor-pointer flex flex-col items-center justify-center gap-2"
          >
            <div className="p-3 rounded-full bg-purple-900/40 text-purple-300">
              {uploadingFile ? (
                <Loader2 className="w-6 h-6 animate-spin text-purple-400" />
              ) : (
                <Upload className="w-6 h-6 text-purple-400" />
              )}
            </div>
            <div>
              <p className="text-xs font-bold text-white">
                {uploadingFile ? 'Uploading file to Firebase Storage...' : 'Click or drag file to upload'}
              </p>
              <p className="text-[10px] text-zinc-400 mt-0.5">
                Supports images, documents, and media assets up to 25MB
              </p>
            </div>
          </label>
        </div>

        {/* Uploaded File List */}
        {files.length > 0 && (
          <div className="space-y-2 mt-3">
            <h4 className="text-xs font-bold text-purple-300 uppercase tracking-wider">Uploaded Storage Objects</h4>
            <div className="space-y-2 max-h-48 overflow-y-auto">
              {files.map((file) => (
                <div
                  key={file.id}
                  className="p-3 rounded-xl bg-zinc-900/80 border border-purple-900/40 flex items-center justify-between text-xs"
                >
                  <div className="flex items-center gap-2.5 overflow-hidden">
                    <div className="p-1.5 rounded-lg bg-purple-950 text-purple-400 shrink-0">
                      <HardDrive className="w-4 h-4" />
                    </div>
                    <div className="truncate">
                      <p className="font-bold text-white truncate">{file.name}</p>
                      <p className="text-[10px] text-zinc-400">
                        {(file.size / 1024).toFixed(1)} KB • By {file.uploadedBy}
                      </p>
                    </div>
                  </div>

                  <a
                    href={file.url}
                    target="_blank"
                    rel="noreferrer"
                    className="p-1.5 rounded-lg bg-purple-900/50 hover:bg-purple-800/60 text-purple-300 transition-colors flex items-center gap-1 shrink-0"
                  >
                    <span>View</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Firebase Hosting & Setup Checklist */}
      <div className="p-5 sm:p-6 rounded-3xl bg-zinc-950/90 border border-purple-800/50 shadow-xl shadow-purple-950/40 space-y-3">
        <div className="flex items-center gap-2">
          <Globe className="w-5 h-5 text-purple-400" />
          <h3 className="font-bold text-base text-white">Firebase Hosting & Deployment Ready</h3>
        </div>
        <p className="text-xs text-zinc-400 leading-relaxed">
          The project structure includes <code className="text-purple-300 bg-purple-900/50 px-1 rounded">firebase.json</code> rewrite rules, <code className="text-purple-300 bg-purple-900/50 px-1 rounded">.firebaserc</code>, <code className="text-purple-300 bg-purple-900/50 px-1 rounded">firestore.rules</code>, and <code className="text-purple-300 bg-purple-900/50 px-1 rounded">storage.rules</code> ready for hosting deployment.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-2 text-xs">
          <div className="p-3 rounded-xl bg-purple-950/40 border border-purple-800/40 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <div>
              <strong className="text-white block">Hosting SPA Rewrite</strong>
              <span className="text-[10px] text-purple-300">Target: /index.html</span>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-purple-950/40 border border-purple-800/40 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <div>
              <strong className="text-white block">Firestore Security Rules</strong>
              <span className="text-[10px] text-purple-300">Auth check enabled</span>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-purple-950/40 border border-purple-800/40 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <div>
              <strong className="text-white block">Storage Security Rules</strong>
              <span className="text-[10px] text-purple-300">Object permissions set</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
