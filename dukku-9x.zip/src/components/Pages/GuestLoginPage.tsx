import React, { useState } from 'react';
import { UserCheck, ShieldCheck, Zap, ArrowRight, Check, Loader2, Sparkles } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { ActivePage } from '../../types';

interface GuestLoginPageProps {
  onNavigate: (page: ActivePage) => void;
}

export const GuestLoginPage: React.FC<GuestLoginPageProps> = ({ onNavigate }) => {
  const { signInAnonymously, user } = useAuth();
  const [loading, setLoading] = useState(false);

  const handleGuestSignIn = async () => {
    setLoading(true);
    try {
      await signInAnonymously();
      onNavigate('home');
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto my-6 animate-fade-in space-y-6">
      <div className="rounded-3xl bg-zinc-950/90 border border-purple-800/50 p-6 sm:p-8 shadow-2xl shadow-purple-950/60 relative overflow-hidden text-center">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-32 bg-purple-600/15 blur-3xl pointer-events-none" />

        <div className="w-14 h-14 rounded-2xl bg-purple-900/50 border border-purple-600/60 flex items-center justify-center mx-auto text-purple-300 mb-4 shadow-md shadow-purple-950">
          <UserCheck className="w-7 h-7" />
        </div>

        <h2 className="text-2xl font-black text-white">Anonymous Guest Login</h2>
        <p className="text-xs text-purple-300/80 mt-1 max-w-xs mx-auto">
          Instantly provision an isolated Firebase Anonymous user token without entering personal details.
        </p>

        {/* Feature List */}
        <div className="my-6 space-y-2.5 text-left bg-purple-950/30 p-4 rounded-2xl border border-purple-900/40">
          <div className="flex items-start gap-2.5 text-xs text-zinc-300">
            <div className="p-0.5 rounded-full bg-emerald-900/60 text-emerald-400 mt-0.5 shrink-0">
              <Check className="w-3 h-3" />
            </div>
            <span>
              <strong className="text-white">Zero Signup Delay:</strong> No password, email validation, or SMS needed.
            </span>
          </div>

          <div className="flex items-start gap-2.5 text-xs text-zinc-300">
            <div className="p-0.5 rounded-full bg-emerald-900/60 text-emerald-400 mt-0.5 shrink-0">
              <Check className="w-3 h-3" />
            </div>
            <span>
              <strong className="text-white">Full Firestore Access:</strong> Read and append documents to Cloud Firestore collections.
            </span>
          </div>

          <div className="flex items-start gap-2.5 text-xs text-zinc-300">
            <div className="p-0.5 rounded-full bg-emerald-900/60 text-emerald-400 mt-0.5 shrink-0">
              <Check className="w-3 h-3" />
            </div>
            <span>
              <strong className="text-white">Storage Uploads:</strong> Test Firebase Storage uploads with anonymous owner metadata.
            </span>
          </div>
        </div>

        {user?.isAnonymous ? (
          <div className="space-y-3">
            <div className="p-3 rounded-xl bg-purple-900/40 border border-purple-700/50 text-xs text-purple-200">
              Active Guest Session: <span className="font-mono font-bold text-white">{user.uid}</span>
            </div>
            <button
              id="guest-continue-home-btn"
              onClick={() => onNavigate('home')}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-bold text-sm shadow-lg shadow-purple-950 flex items-center justify-center gap-2"
            >
              <span>Continue to Home Dashboard</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            <button
              id="guest-login-action-btn"
              onClick={handleGuestSignIn}
              disabled={loading}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-purple-600 via-purple-700 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-sm shadow-xl shadow-purple-950/80 flex items-center justify-center gap-2 transition-all cursor-pointer transform hover:-translate-y-0.5 disabled:opacity-50"
            >
              {loading ? (
                <Loader2 className="w-4 h-4 animate-spin text-white" />
              ) : (
                <>
                  <Zap className="w-4 h-4 text-purple-200 fill-purple-300" />
                  <span>Enter as Anonymous Guest</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>

            <button
              id="guest-back-to-login-btn"
              onClick={() => onNavigate('login')}
              className="text-xs text-zinc-400 hover:text-purple-300 font-medium transition-colors"
            >
              Prefer standard email login instead?
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
