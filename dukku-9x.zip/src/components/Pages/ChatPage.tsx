import React, { useState, useEffect, useRef } from 'react';
import {
  Send,
  SkipForward,
  ShieldAlert,
  Image as ImageIcon,
  Loader2,
  RefreshCw,
  Sparkles,
  User,
  Zap,
  X,
  AlertOctagon,
  Smile,
  Hash,
  Radio,
  CheckCheck,
  Maximize2
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { chatService } from '../../lib/chatService';
import { ChatMessage, ChatSession, ActivePage } from '../../types';

interface ChatPageProps {
  onNavigate: (page: ActivePage) => void;
}

const INTEREST_TAGS = ['General', 'Tech & AI', 'Music & Movies', 'Gaming', 'Anime', 'Crypto'];

export const ChatPage: React.FC<ChatPageProps> = ({ onNavigate }) => {
  const { user } = useAuth();

  // Chat Session state
  const [chatSession, setChatSession] = useState<ChatSession | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [selectedTag, setSelectedTag] = useState('General');

  // Input & typing state
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [uploadingImage, setUploadingImage] = useState(false);

  // UI Modals & Previews
  const [showReportModal, setShowReportModal] = useState(false);
  const [reportReason, setReportReason] = useState('Inappropriate behavior');
  const [zoomedImage, setZoomedImage] = useState<string | null>(null);

  // Refs
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);
  const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const queueCleanupRef = useRef<(() => Promise<void>) | null>(null);

  // Scroll to bottom whenever messages update
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, chatSession?.typing]);

  // Clean up queue listeners on unmount
  useEffect(() => {
    return () => {
      if (queueCleanupRef.current) {
        queueCleanupRef.current();
      }
    };
  }, []);

  // 1. Start Matchmaking function
  const handleStartMatchmaking = async () => {
    if (!user) {
      onNavigate('login');
      return;
    }

    // Clean previous chat state
    setChatSession(null);
    setMessages([]);
    setIsSearching(true);

    if (queueCleanupRef.current) {
      await queueCleanupRef.current();
      queueCleanupRef.current = null;
    }

    const { unsubscribe, cancelQueue } = await chatService.joinQueue(
      user,
      selectedTag,
      (matchedChat) => {
        setChatSession(matchedChat);
        setIsSearching(false);
      },
      () => {
        setIsSearching(true);
      }
    );

    queueCleanupRef.current = async () => {
      unsubscribe();
      await cancelQueue();
    };
  };

  // 2. Auto-start search on initial page mount if no chat exists
  useEffect(() => {
    if (user && !chatSession && !isSearching) {
      handleStartMatchmaking();
    }
  }, [user]);

  // 3. Listen to Active Chat messages & session state changes
  useEffect(() => {
    if (!chatSession?.id) return;

    // Listen to messages
    const unsubMessages = chatService.listenToMessages(chatSession.id, (newMsgs) => {
      setMessages(newMsgs);
    });

    // Listen to chat session (for ended state / typing updates)
    const unsubSession = chatService.listenToChatSession(chatSession.id, (updatedSession) => {
      setChatSession(updatedSession);
    });

    return () => {
      unsubMessages();
      unsubSession();
    };
  }, [chatSession?.id]);

  // Handle typing indicator
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputText(e.target.value);

    if (!chatSession || !user) return;

    if (!isTyping) {
      setIsTyping(true);
      chatService.setTyping(chatSession.id, user.uid, true);
    }

    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);

    typingTimeoutRef.current = setTimeout(() => {
      setIsTyping(false);
      chatService.setTyping(chatSession.id, user.uid, false);
    }, 1500);
  };

  // Send text message
  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || !chatSession || !user) return;

    const messageText = inputText.trim();
    setInputText('');

    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
    setIsTyping(false);
    chatService.setTyping(chatSession.id, user.uid, false);

    const partnerUid = chatSession.participants.find((id) => id !== user.uid);
    const senderName = user.displayName || (user.isAnonymous ? 'You' : 'Operator');

    await chatService.sendMessage(
      chatSession.id,
      user.uid,
      senderName,
      messageText,
      partnerUid
    );
  };

  // Image Upload handler via Firebase Storage
  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !chatSession || !user) return;

    setUploadingImage(true);
    try {
      const senderName = user.displayName || (user.isAnonymous ? 'You' : 'Operator');
      await chatService.sendImageMessage(chatSession.id, user.uid, senderName, file);
    } catch (err) {
      console.error('Image upload failed:', err);
    } finally {
      setUploadingImage(false);
      if (imageInputRef.current) imageInputRef.current.value = '';
    }
  };

  // Skip Current Stranger Partner
  const handleSkipPartner = async () => {
    if (chatSession && user) {
      await chatService.skipPartner(chatSession.id, user.uid);
    }
    handleStartMatchmaking();
  };

  // Report & Block Partner
  const handleReportAndBlock = async () => {
    if (!chatSession || !user) return;
    const partnerUid = chatSession.participants.find((id) => id !== user.uid);
    if (partnerUid) {
      await chatService.reportAndBlock(
        chatSession.id,
        user.uid,
        partnerUid,
        reportReason
      );
    }
    setShowReportModal(false);
    handleStartMatchmaking();
  };

  // Find partner details
  const partnerUid = chatSession?.participants.find((id) => id !== user?.uid);
  const partnerDetails = partnerUid ? chatSession?.participantDetails?.[partnerUid] : null;
  const partnerIsTyping = partnerUid ? chatSession?.typing?.[partnerUid] : false;
  const isChatEnded = chatSession?.status === 'ended';

  return (
    <div className="flex flex-col h-[calc(100vh-140px)] sm:h-[calc(100vh-120px)] max-h-[780px] rounded-3xl bg-zinc-950 border border-purple-800/50 shadow-2xl shadow-purple-950/80 overflow-hidden animate-fade-in relative">
      {/* --- CHAT TOP NAVIGATION BAR --- */}
      <div className="bg-zinc-900/90 border-b border-purple-900/50 p-3 px-4 flex items-center justify-between gap-2 z-10">
        {/* Left: Partner info & online dot */}
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-purple-700 to-indigo-900 border border-purple-500/50 flex items-center justify-center overflow-hidden shadow-md shadow-purple-950">
              {partnerDetails?.photoURL ? (
                <img src={partnerDetails.photoURL} alt="Partner" className="w-full h-full object-cover" />
              ) : (
                <User className="w-5 h-5 text-purple-200" />
              )}
            </div>
            <span
              className={`absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full border-2 border-zinc-900 ${
                isChatEnded ? 'bg-red-500' : isSearching ? 'bg-amber-400 animate-pulse' : 'bg-emerald-500'
              }`}
            />
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-sm text-white truncate max-w-[130px] sm:max-w-[200px]">
                {isSearching
                  ? 'Searching Stranger...'
                  : partnerDetails?.displayName || 'Anonymous Stranger'}
              </h3>
              <span className="text-[10px] px-2 py-0.2 rounded-full bg-purple-950 border border-purple-700/50 text-purple-300 font-semibold hidden sm:inline-block">
                #{chatSession?.interestTag || selectedTag}
              </span>
            </div>
            <p className="text-[10px] text-zinc-400 flex items-center gap-1">
              {isSearching ? (
                <span className="text-amber-400 font-medium flex items-center gap-1">
                  <Radio className="w-3 h-3 animate-spin" /> Radar Scanning...
                </span>
              ) : isChatEnded ? (
                <span className="text-red-400 font-medium">Partner disconnected</span>
              ) : partnerIsTyping ? (
                <span className="text-purple-300 font-medium animate-pulse">Stranger is typing...</span>
              ) : (
                <span className="text-emerald-400 font-medium">1-on-1 Connected</span>
              )}
            </p>
          </div>
        </div>

        {/* Right: Controls (Skip / Report) */}
        <div className="flex items-center gap-1.5">
          {chatSession && !isSearching && (
            <>
              <button
                id="skip-partner-btn"
                onClick={handleSkipPartner}
                className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-purple-900/60 hover:bg-purple-800 border border-purple-600/60 text-white text-xs font-bold transition-all shadow-md shadow-purple-950 cursor-pointer active:scale-95"
                title="Skip & Match Next Stranger"
              >
                <SkipForward className="w-3.5 h-3.5 text-purple-200 fill-purple-300" />
                <span className="hidden sm:inline">Next</span>
              </button>

              <button
                id="report-partner-btn"
                onClick={() => setShowReportModal(true)}
                className="p-1.5 rounded-xl bg-zinc-900 hover:bg-red-950/60 border border-purple-900/40 text-zinc-400 hover:text-red-300 transition-colors"
                title="Report & Block Stranger"
              >
                <ShieldAlert className="w-4 h-4" />
              </button>
            </>
          )}

          {isSearching && (
            <button
              id="cancel-search-btn"
              onClick={() => {
                if (queueCleanupRef.current) queueCleanupRef.current();
                setIsSearching(false);
              }}
              className="p-1.5 rounded-xl bg-zinc-900 text-zinc-400 hover:text-white border border-purple-900/40 text-xs"
            >
              Cancel
            </button>
          )}
        </div>
      </div>

      {/* --- SEARCHING / MATCHMAKING RADAR OVERLAY --- */}
      {isSearching && (
        <div className="flex-1 flex flex-col items-center justify-center p-6 text-center space-y-6 bg-zinc-950/95 relative z-20">
          <div className="relative">
            <div className="w-24 h-24 rounded-full bg-purple-950/60 border-2 border-purple-600/60 flex items-center justify-center animate-ping absolute inset-0 opacity-40" />
            <div className="w-24 h-24 rounded-full bg-gradient-to-br from-purple-700 via-purple-900 to-indigo-950 border border-purple-500/80 flex items-center justify-center shadow-2xl shadow-purple-900/80 relative z-10">
              <Zap className="w-10 h-10 text-white animate-bounce" />
            </div>
          </div>

          <div className="space-y-1.5 max-w-xs">
            <h3 className="text-xl font-extrabold text-white">Finding Online Stranger</h3>
            <p className="text-xs text-purple-300/80">
              Matching you with a random partner under <span className="text-purple-300 font-bold">#{selectedTag}</span>...
            </p>
          </div>

          {/* Tag Selector for Matchmaking */}
          <div className="w-full max-w-sm space-y-2">
            <span className="text-[10px] font-bold uppercase tracking-wider text-purple-400 flex items-center justify-center gap-1">
              <Hash className="w-3 h-3" /> Select Preferred Filter Tag
            </span>
            <div className="flex flex-wrap justify-center gap-1.5">
              {INTEREST_TAGS.map((tag) => (
                <button
                  key={tag}
                  id={`tag-filter-${tag}`}
                  onClick={() => {
                    setSelectedTag(tag);
                    handleStartMatchmaking();
                  }}
                  className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
                    selectedTag === tag
                      ? 'bg-purple-600 text-white font-bold border border-purple-400 shadow-md shadow-purple-950'
                      : 'bg-zinc-900 text-zinc-400 hover:text-purple-300 border border-purple-950'
                  }`}
                >
                  #{tag}
                </button>
              ))}
            </div>
          </div>

          <button
            id="radar-retry-btn"
            onClick={handleStartMatchmaking}
            className="flex items-center gap-2 px-5 py-2.5 rounded-2xl bg-purple-900/60 hover:bg-purple-800 text-purple-200 text-xs font-semibold border border-purple-600/50"
          >
            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
            <span>Restart Radar Search</span>
          </button>
        </div>
      )}

      {/* --- MESSAGES FEED AREA --- */}
      {!isSearching && (
        <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar">
          {messages.length === 0 && (
            <div className="py-12 text-center text-xs text-purple-300/60 space-y-2">
              <Sparkles className="w-8 h-8 text-purple-500/60 mx-auto" />
              <p className="font-semibold text-white text-sm">Real-time Connection Established!</p>
              <p>Type a greeting or upload a photo to break the ice.</p>
            </div>
          )}

          {messages.map((msg) => {
            const isMe = msg.senderId === user?.uid;
            const isSystem = msg.type === 'system';

            if (isSystem) {
              return (
                <div key={msg.id} className="flex justify-center my-2">
                  <span className="px-3 py-1 rounded-full bg-purple-950/80 border border-purple-800/40 text-[11px] text-purple-300 font-medium text-center max-w-xs shadow-sm">
                    {msg.text}
                  </span>
                </div>
              );
            }

            return (
              <div
                key={msg.id}
                className={`flex flex-col ${isMe ? 'items-end' : 'items-start'} my-1 animate-fade-in`}
              >
                <div className="flex items-end gap-1.5 max-w-[85%] sm:max-w-[75%]">
                  {!isMe && (
                    <div className="w-6 h-6 rounded-lg bg-purple-900 border border-purple-600/40 flex items-center justify-center shrink-0 mb-1 text-[10px] text-purple-300 font-bold overflow-hidden">
                      {partnerDetails?.photoURL ? (
                        <img src={partnerDetails.photoURL} alt="" className="w-full h-full object-cover" />
                      ) : (
                        'S'
                      )}
                    </div>
                  )}

                  <div
                    className={`rounded-2xl p-3 text-xs leading-relaxed break-words shadow-md ${
                      isMe
                        ? 'bg-gradient-to-r from-purple-700 via-purple-800 to-indigo-900 text-white rounded-br-none border border-purple-600/50'
                        : 'bg-zinc-900 text-zinc-100 rounded-bl-none border border-purple-900/50'
                    }`}
                  >
                    {msg.imageUrl && (
                      <div className="mb-2 relative rounded-xl overflow-hidden border border-purple-700/40 group">
                        <img
                          src={msg.imageUrl}
                          alt="Attachment"
                          className="max-h-52 w-full object-cover cursor-pointer hover:opacity-90 transition-opacity"
                          onClick={() => setZoomedImage(msg.imageUrl || null)}
                        />
                        <button
                          onClick={() => setZoomedImage(msg.imageUrl || null)}
                          className="absolute top-2 right-2 p-1.5 rounded-lg bg-black/60 text-white opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <Maximize2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    )}

                    <p>{msg.text}</p>

                    <div
                      className={`flex items-center gap-1 mt-1 text-[9px] ${
                        isMe ? 'text-purple-300/80 justify-end' : 'text-zinc-500 justify-start'
                      }`}
                    >
                      <span>
                        {new Date(msg.createdAt).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </span>
                      {isMe && <CheckCheck className="w-3 h-3 text-purple-300" />}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}

          {/* Typing Indicator */}
          {partnerIsTyping && (
            <div className="flex items-center gap-2 text-xs text-purple-300/80 bg-zinc-900/60 p-2.5 rounded-2xl w-max border border-purple-900/30">
              <div className="flex items-center gap-1">
                <span className="w-1.5 h-1.5 bg-purple-400 rounded-full animate-bounce" />
                <span className="w-1.5 h-1.5 bg-purple-400 rounded-full animate-bounce [animation-delay:0.2s]" />
                <span className="w-1.5 h-1.5 bg-purple-400 rounded-full animate-bounce [animation-delay:0.4s]" />
              </div>
              <span className="text-[11px]">Stranger is typing...</span>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>
      )}

      {/* --- CHAT DISCONNECTED ALERT BANNER --- */}
      {isChatEnded && !isSearching && (
        <div className="bg-purple-950/90 border-t border-purple-800/60 p-3 px-4 flex items-center justify-between gap-2 z-10">
          <p className="text-xs text-purple-200">
            Chat ended or partner left.
          </p>
          <button
            id="reconnect-next-stranger-btn"
            onClick={handleStartMatchmaking}
            className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 text-white text-xs font-bold flex items-center gap-1.5 shadow-lg shadow-purple-950 cursor-pointer"
          >
            <SkipForward className="w-3.5 h-3.5" />
            <span>Connect Next Stranger</span>
          </button>
        </div>
      )}

      {/* --- INPUT BAR --- */}
      {!isSearching && (
        <div className="bg-zinc-900/95 border-t border-purple-900/50 p-2.5 px-3 z-10">
          <form onSubmit={handleSendMessage} className="flex items-center gap-2">
            {/* Hidden File Input for Firebase Storage Image Upload */}
            <input
              type="file"
              ref={imageInputRef}
              accept="image/*"
              onChange={handleImageUpload}
              className="hidden"
            />

            <button
              id="chat-upload-img-btn"
              type="button"
              disabled={isChatEnded || uploadingImage}
              onClick={() => imageInputRef.current?.click()}
              className="p-2.5 rounded-xl bg-zinc-800/80 hover:bg-purple-950/60 text-zinc-400 hover:text-purple-300 border border-purple-900/30 transition-colors disabled:opacity-40 cursor-pointer"
              title="Send Image Attachment"
            >
              {uploadingImage ? (
                <Loader2 className="w-4 h-4 animate-spin text-purple-400" />
              ) : (
                <ImageIcon className="w-4 h-4" />
              )}
            </button>

            <input
              id="chat-message-input"
              type="text"
              disabled={isChatEnded}
              placeholder={isChatEnded ? 'Chat ended. Click next above.' : 'Type your anonymous message...'}
              value={inputText}
              onChange={handleInputChange}
              className="flex-1 px-4 py-2.5 rounded-xl bg-zinc-950 border border-purple-900/50 text-white text-sm focus:outline-none focus:border-purple-500 disabled:opacity-40 transition-colors"
            />

            <button
              id="chat-send-msg-btn"
              type="submit"
              disabled={isChatEnded || !inputText.trim()}
              className="p-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold transition-all disabled:opacity-40 cursor-pointer shadow-md shadow-purple-950"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}

      {/* --- REPORT MODAL --- */}
      {showReportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-zinc-950 border border-purple-800/60 rounded-3xl p-6 max-w-sm w-full shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-red-400">
                <AlertOctagon className="w-5 h-5" />
                <h3 className="font-bold text-white text-base">Report & Block Stranger</h3>
              </div>
              <button
                onClick={() => setShowReportModal(false)}
                className="text-zinc-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-zinc-400">
              This will immediately disconnect the chat and block this user from being matched with you in future queues.
            </p>

            <div className="space-y-2">
              <label className="text-xs font-semibold text-purple-300">Reason</label>
              <select
                value={reportReason}
                onChange={(e) => setReportReason(e.target.value)}
                className="w-full p-2.5 rounded-xl bg-zinc-900 border border-purple-900 text-white text-xs"
              >
                <option value="Inappropriate behavior">Inappropriate or offensive behavior</option>
                <option value="Spam / Bot">Spam or bot messages</option>
                <option value="Harassment">Harassment</option>
                <option value="Other">Other</option>
              </select>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                id="cancel-report-btn"
                onClick={() => setShowReportModal(false)}
                className="flex-1 py-2.5 rounded-xl bg-zinc-900 text-zinc-300 text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                id="confirm-report-btn"
                onClick={handleReportAndBlock}
                className="flex-1 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold"
              >
                Block & Match Next
              </button>
            </div>
          </div>
        </div>
      )}

      {/* --- IMAGE ZOOM MODAL --- */}
      {zoomedImage && (
        <div
          onClick={() => setZoomedImage(null)}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md cursor-pointer animate-fade-in"
        >
          <div className="relative max-w-2xl max-h-[85vh]">
            <img src={zoomedImage} alt="Enlarged preview" className="rounded-2xl max-h-[85vh] object-contain border border-purple-600/50 shadow-2xl" />
            <button
              onClick={() => setZoomedImage(null)}
              className="absolute -top-3 -right-3 p-2 rounded-full bg-purple-950 text-white border border-purple-500 shadow-lg"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
