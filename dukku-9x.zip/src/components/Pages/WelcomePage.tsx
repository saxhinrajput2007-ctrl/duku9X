import React from 'react';
import { Shield, Database, HardDrive, Globe, ArrowRight, Zap, CheckCircle, Sparkles, UserCheck, MessageSquare, Radio, Users } from 'lucide-react';
import { ActivePage } from '../../types';
import { useAuth } from '../../context/AuthContext';

interface WelcomePageProps {
  onNavigate: (page: ActivePage) => void;
}

export const WelcomePage: React.FC<WelcomePageProps> = ({ onNavigate }) => {
  const { user } = useAuth();

  return (
    <div className="space-y-6 pb-8 animate-fade-in">
      {/* Hero Card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-b from-purple-950/80 via-zinc-950 to-black border border-purple-800/50 p-6 sm:p-10 text-center shadow-2xl shadow-purple-950/80">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-32 bg-purple-600/30 blur-3xl pointer-events-none -z-0" />

        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-purple-900/60 border border-purple-500/60 text-purple-200 text-xs font-bold mb-4 shadow-md shadow-purple-950">
          <Radio className="w-3.5 h-3.5 text-purple-300 animate-pulse" />
          <span>Real-time Anonymous Stranger Matchmaking</span>
        </div>

        <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight leading-tight">
          Connect Anonymously with <br />
          <span className="bg-gradient-to-r from-purple-400 via-purple-300 to-indigo-400 bg-clip-text text-transparent">
            Strangers Worldwide
          </span>
        </h1>

        <p className="mt-3 text-sm sm:text-base text-zinc-300 max-w-xl mx-auto leading-relaxed">
          1-on-1 instant encrypted chat, real-time typing indicators, interest tag filters, image attachments via Firebase Storage, and instant partner skipping!
        </p>

        {/* Call To Action buttons */}
        <div className="mt-6 flex flex-col sm:flex-row items-center justify-center gap-3">
          <button
            id="welcome-start-chat-cta"
            onClick={() => onNavigate('chat')}
            className="w-full sm:w-auto px-8 py-3.5 rounded-2xl bg-gradient-to-r from-purple-600 via-purple-700 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-extrabold text-sm sm:text-base shadow-xl shadow-purple-900/60 flex items-center justify-center gap-2.5 transition-all transform hover:-translate-y-0.5 cursor-pointer"
          >
            <MessageSquare className="w-5 h-5 text-purple-200" />
            <span>Start Anonymous Chat Now</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          {!user && (
            <button
              id="welcome-guest-cta"
              onClick={() => onNavigate('guest')}
              className="w-full sm:w-auto px-6 py-3.5 rounded-2xl bg-zinc-900/90 hover:bg-purple-950/80 border border-purple-700/50 text-purple-200 font-medium text-sm flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <UserCheck className="w-4 h-4 text-purple-400" />
              <span>1-Click Guest Login</span>
            </button>
          )}
        </div>
      </div>

      {/* Feature Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Matchmaking Queue */}
        <div
          onClick={() => onNavigate('chat')}
          className="group p-5 rounded-2xl bg-zinc-950/80 border border-purple-900/40 hover:border-purple-600/60 transition-all cursor-pointer relative overflow-hidden"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="p-3 rounded-xl bg-purple-950/80 border border-purple-800/50 text-purple-400 group-hover:scale-110 transition-transform">
              <Users className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-purple-300 bg-purple-900/50 px-2 py-0.5 rounded-full border border-purple-700/40">
              Firestore Real-Time
            </span>
          </div>
          <h3 className="text-base font-bold text-white group-hover:text-purple-300 transition-colors">
            Random 1-on-1 Matchmaking
          </h3>
          <p className="text-xs text-zinc-400 mt-1 leading-relaxed">
            Instant matchmaking queue with topic filtering (#Tech, #Gaming, #Anime, #Music, #General).
          </p>
          <div className="mt-3 flex items-center gap-1 text-xs text-purple-400 font-medium">
            <span>Enter Radar Queue</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>

        {/* Realtime Typing & Messages */}
        <div
          onClick={() => onNavigate('chat')}
          className="group p-5 rounded-2xl bg-zinc-950/80 border border-purple-900/40 hover:border-purple-600/60 transition-all cursor-pointer relative overflow-hidden"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="p-3 rounded-xl bg-purple-950/80 border border-purple-800/50 text-purple-400 group-hover:scale-110 transition-transform">
              <MessageSquare className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-purple-300 bg-purple-900/50 px-2 py-0.5 rounded-full border border-purple-700/40">
              Live Presence
            </span>
          </div>
          <h3 className="text-base font-bold text-white group-hover:text-purple-300 transition-colors">
            Typing Indicators & Status
          </h3>
          <p className="text-xs text-zinc-400 mt-1 leading-relaxed">
            See when your stranger partner is actively typing, online presence, and partner disconnect detection.
          </p>
          <div className="mt-3 flex items-center gap-1 text-xs text-purple-400 font-medium">
            <span>Open Chat Room</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>

        {/* Firebase Storage Image Attachments */}
        <div
          onClick={() => onNavigate('chat')}
          className="group p-5 rounded-2xl bg-zinc-950/80 border border-purple-900/40 hover:border-purple-600/60 transition-all cursor-pointer relative overflow-hidden"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="p-3 rounded-xl bg-purple-950/80 border border-purple-800/50 text-purple-400 group-hover:scale-110 transition-transform">
              <HardDrive className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-purple-300 bg-purple-900/50 px-2 py-0.5 rounded-full border border-purple-700/40">
              Storage Bucket
            </span>
          </div>
          <h3 className="text-base font-bold text-white group-hover:text-purple-300 transition-colors">
            Image Attachments & Zoom
          </h3>
          <p className="text-xs text-zinc-400 mt-1 leading-relaxed">
            Upload images during live chat via Firebase Storage with interactive lightbox previews.
          </p>
          <div className="mt-3 flex items-center gap-1 text-xs text-purple-400 font-medium">
            <span>Try Photo Upload</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>

        {/* Skip, Report & Safety */}
        <div
          onClick={() => onNavigate('chat')}
          className="group p-5 rounded-2xl bg-zinc-950/80 border border-purple-900/40 hover:border-purple-600/60 transition-all cursor-pointer relative overflow-hidden"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="p-3 rounded-xl bg-purple-950/80 border border-purple-800/50 text-purple-400 group-hover:scale-110 transition-transform">
              <Shield className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-purple-300 bg-purple-900/50 px-2 py-0.5 rounded-full border border-purple-700/40">
              Safety Controls
            </span>
          </div>
          <h3 className="text-base font-bold text-white group-hover:text-purple-300 transition-colors">
            Skip, Report & Block
          </h3>
          <p className="text-xs text-zinc-400 mt-1 leading-relaxed">
            Instantly skip partners with 1-click and block abusive users from future matchmaking queues.
          </p>
          <div className="mt-3 flex items-center gap-1 text-xs text-purple-400 font-medium">
            <span>View Safety Controls</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>
      </div>

      {/* Tech Specs Banner */}
      <div className="p-5 rounded-2xl bg-purple-950/30 border border-purple-800/30">
        <h4 className="text-xs font-bold uppercase tracking-wider text-purple-300 mb-3 flex items-center gap-2">
          <Zap className="w-4 h-4 text-purple-400" />
          Dukku 9X Firebase Infrastructure
        </h4>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
          <div className="flex items-center gap-1.5 text-zinc-300 bg-black/40 p-2 rounded-lg border border-purple-900/30">
            <CheckCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span>Firebase Auth</span>
          </div>
          <div className="flex items-center gap-1.5 text-zinc-300 bg-black/40 p-2 rounded-lg border border-purple-900/30">
            <CheckCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span>Cloud Firestore</span>
          </div>
          <div className="flex items-center gap-1.5 text-zinc-300 bg-black/40 p-2 rounded-lg border border-purple-900/30">
            <CheckCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span>Firebase Storage</span>
          </div>
          <div className="flex items-center gap-1.5 text-zinc-300 bg-black/40 p-2 rounded-lg border border-purple-900/30">
            <CheckCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span>Black & Purple UI</span>
          </div>
        </div>
      </div>
    </div>
  );
};

