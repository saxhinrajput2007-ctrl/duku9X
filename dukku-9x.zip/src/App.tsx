import React, { useState } from 'react';
import { AuthProvider } from './context/AuthContext';
import { ActivePage } from './types';
import { Header } from './components/Header';
import { MobileFrame } from './components/MobileFrame';
import { WelcomePage } from './components/Pages/WelcomePage';
import { ChatPage } from './components/Pages/ChatPage';
import { LoginPage } from './components/Pages/LoginPage';
import { GuestLoginPage } from './components/Pages/GuestLoginPage';
import { HomePage } from './components/Pages/HomePage';

function AppContent() {
  const [activePage, setActivePage] = useState<ActivePage>('chat');
  const [isMobileDeviceFrame, setIsMobileDeviceFrame] = useState(false);

  return (
    <MobileFrame isMobileDeviceFrame={isMobileDeviceFrame}>
      <div className="min-h-screen bg-black text-zinc-100 flex flex-col font-sans selection:bg-purple-600 selection:text-white">
        {/* Navigation Header */}
        <Header
          activePage={activePage}
          onSelectPage={setActivePage}
          isMobileDeviceFrame={isMobileDeviceFrame}
          onToggleFrame={() => setIsMobileDeviceFrame(!isMobileDeviceFrame)}
        />

        {/* Page Content Viewport */}
        <main className="flex-1 max-w-5xl w-full mx-auto p-3 sm:p-6 flex flex-col">
          {activePage === 'chat' && <ChatPage onNavigate={setActivePage} />}
          {activePage === 'welcome' && <WelcomePage onNavigate={setActivePage} />}
          {activePage === 'login' && <LoginPage onNavigate={setActivePage} />}
          {activePage === 'guest' && <GuestLoginPage onNavigate={setActivePage} />}
          {activePage === 'home' && <HomePage onNavigate={setActivePage} />}
        </main>

        {/* Footer */}
        <footer className="border-t border-purple-950 bg-zinc-950/80 py-3 px-4 text-center text-xs text-zinc-500 mt-auto">
          <div className="max-w-5xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
            <p className="flex items-center gap-1">
              <span className="font-bold text-purple-300">Dukku 9X</span>
              <span>— Anonymous Stranger Chat App</span>
            </p>
            <div className="flex items-center gap-3 text-[11px] text-zinc-400">
              <button onClick={() => setActivePage('chat')} className="hover:text-purple-300 font-semibold">Stranger Chat</button>
              <span>•</span>
              <button onClick={() => setActivePage('welcome')} className="hover:text-purple-300">Welcome</button>
              <span>•</span>
              <button onClick={() => setActivePage('login')} className="hover:text-purple-300">Login</button>
              <span>•</span>
              <button onClick={() => setActivePage('guest')} className="hover:text-purple-300">Guest</button>
              <span>•</span>
              <button onClick={() => setActivePage('home')} className="hover:text-purple-300">Dashboard</button>
            </div>
          </div>
        </footer>
      </div>
    </MobileFrame>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
