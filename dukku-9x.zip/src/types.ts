export interface UserProfile {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
  isAnonymous: boolean;
  createdAt: string;
  lastLoginAt: string;
  role?: string;
  themePreference?: 'dark' | 'neon-purple';
  blockedUsers?: string[];
  chatCount?: number;
}

export interface ChatMessage {
  id: string;
  chatId: string;
  senderId: string;
  senderName: string;
  text: string;
  imageUrl?: string;
  type: 'text' | 'image' | 'system';
  createdAt: string;
}

export interface ChatSession {
  id: string;
  participants: string[];
  participantDetails: Record<string, {
    displayName: string;
    photoURL: string;
    isAnonymous: boolean;
  }>;
  status: 'active' | 'ended';
  endedBy?: string | null;
  typing?: Record<string, boolean>;
  lastMessage?: string;
  lastMessageAt?: string;
  createdAt: string;
  interestTag?: string;
}

export interface QueueUser {
  uid: string;
  displayName: string;
  photoURL: string;
  isAnonymous: boolean;
  joinedAt: string;
  status: 'waiting' | 'matched';
  activeChatId?: string | null;
  interestTag?: string;
  blockedUsers?: string[];
}

export interface SetupTask {
  id: string;
  title: string;
  category: 'auth' | 'firestore' | 'storage' | 'hosting';
  status: 'completed' | 'configured' | 'pending';
  description: string;
}

export interface FirestoreDemoItem {
  id: string;
  title: string;
  category: string;
  createdAt: string;
  createdBy: string;
  isGuestItem: boolean;
}

export interface StorageDemoFile {
  id: string;
  name: string;
  size: number;
  type: string;
  url: string;
  uploadedAt: string;
  uploadedBy: string;
}

export type ActivePage = 'welcome' | 'chat' | 'login' | 'guest' | 'home';

