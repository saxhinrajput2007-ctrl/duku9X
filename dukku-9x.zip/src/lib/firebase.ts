import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import {
  getAuth,
  Auth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInAnonymously as firebaseSignInAnonymously,
  signOut as firebaseSignOut,
  onAuthStateChanged as firebaseOnAuthStateChanged,
  User as FirebaseUser,
  GoogleAuthProvider,
  signInWithPopup
} from 'firebase/auth';
import {
  getFirestore,
  Firestore,
  collection,
  addDoc,
  getDocs,
  deleteDoc,
  doc,
  query,
  orderBy,
  limit
} from 'firebase/firestore';
import {
  getStorage,
  FirebaseStorage,
  ref,
  uploadBytes,
  getDownloadURL
} from 'firebase/storage';
import { UserProfile, FirestoreDemoItem, StorageDemoFile } from '../types';

import appletConfig from '../../firebase-applet-config.json';

// Check for Firebase Config from environment variables or generated applet config
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || appletConfig?.apiKey || '',
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || appletConfig?.authDomain || '',
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || appletConfig?.projectId || '',
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || appletConfig?.storageBucket || '',
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || appletConfig?.messagingSenderId || '',
  appId: import.meta.env.VITE_FIREBASE_APP_ID || appletConfig?.appId || '',
};

export const isFirebaseConfigured = Boolean(
  firebaseConfig.apiKey && firebaseConfig.projectId
);

let app: FirebaseApp | null = null;
let auth: Auth | null = null;
let db: Firestore | null = null;
let storage: FirebaseStorage | null = null;

if (isFirebaseConfigured) {
  try {
    app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
    auth = getAuth(app);
    if (appletConfig?.firestoreDatabaseId && appletConfig.firestoreDatabaseId !== '(default)') {
      db = getFirestore(app, appletConfig.firestoreDatabaseId);
    } else {
      db = getFirestore(app);
    }
    storage = getStorage(app);
    console.log('⚡ Dukku 9X: Firebase initialized successfully with production config.');
  } catch (error) {
    console.warn('⚠️ Dukku 9X: Error initializing Firebase, using client state fallback.', error);
  }
} else {
  console.log('ℹ️ Dukku 9X: Running in client demo mode. Add VITE_FIREBASE_* keys to connect your Firebase cloud backend.');
}

export { auth, db, storage };

// --- Local persistent fallback helpers when keys aren't added yet ---
const MOCK_USER_KEY = 'dukku9x_mock_user';
const MOCK_FIRESTORE_KEY = 'dukku9x_mock_firestore';
const MOCK_STORAGE_KEY = 'dukku9x_mock_storage';

// Initialize default local items
const getLocalItems = (): FirestoreDemoItem[] => {
  try {
    const data = localStorage.getItem(MOCK_FIRESTORE_KEY);
    if (data) return JSON.parse(data);
  } catch (e) {
    console.error(e);
  }
  const defaultItems: FirestoreDemoItem[] = [
    {
      id: 'item-1',
      title: 'Dukku 9X Core Engine Booted',
      category: 'System',
      createdAt: new Date().toISOString(),
      createdBy: 'System Engine',
      isGuestItem: false,
    },
    {
      id: 'item-2',
      title: 'Firebase Firestore Rules Ready',
      category: 'Database',
      createdAt: new Date(Date.now() - 3600000).toISOString(),
      createdBy: 'Admin',
      isGuestItem: false,
    },
  ];
  localStorage.setItem(MOCK_FIRESTORE_KEY, JSON.stringify(defaultItems));
  return defaultItems;
};

const saveLocalItems = (items: FirestoreDemoItem[]) => {
  localStorage.setItem(MOCK_FIRESTORE_KEY, JSON.stringify(items));
};

const getLocalStorageFiles = (): StorageDemoFile[] => {
  try {
    const data = localStorage.getItem(MOCK_STORAGE_KEY);
    if (data) return JSON.parse(data);
  } catch (e) {
    console.error(e);
  }
  return [
    {
      id: 'file-1',
      name: 'dukku9x-blueprint.pdf',
      size: 1024 * 342,
      type: 'application/pdf',
      url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=400&q=80',
      uploadedAt: new Date().toISOString(),
      uploadedBy: 'System',
    },
  ];
};

const saveLocalStorageFiles = (files: StorageDemoFile[]) => {
  localStorage.setItem(MOCK_STORAGE_KEY, JSON.stringify(files));
};

// --- AUTH SERVICES ---
export const authService = {
  subscribe(callback: (user: UserProfile | null) => void) {
    if (auth) {
      return firebaseOnAuthStateChanged(auth, (fbUser: FirebaseUser | null) => {
        if (fbUser) {
          const profile: UserProfile = {
            uid: fbUser.uid,
            email: fbUser.email,
            displayName: fbUser.displayName || (fbUser.isAnonymous ? 'Anonymous Guest' : 'Dukku Agent'),
            photoURL: fbUser.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${fbUser.uid}`,
            isAnonymous: fbUser.isAnonymous,
            createdAt: new Date().toISOString(),
            lastLoginAt: new Date().toISOString(),
          };
          callback(profile);
        } else {
          callback(null);
        }
      });
    } else {
      // Fallback auth subscription
      const checkUser = () => {
        try {
          const stored = localStorage.getItem(MOCK_USER_KEY);
          callback(stored ? JSON.parse(stored) : null);
        } catch {
          callback(null);
        }
      };
      checkUser();
      window.addEventListener('storage', checkUser);
      return () => window.removeEventListener('storage', checkUser);
    }
  },

  async loginWithEmail(email: string, pass: string): Promise<UserProfile> {
    if (auth) {
      const cred = await signInWithEmailAndPassword(auth, email, pass);
      return {
        uid: cred.user.uid,
        email: cred.user.email,
        displayName: cred.user.displayName || email.split('@')[0],
        photoURL: cred.user.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${cred.user.uid}`,
        isAnonymous: false,
        createdAt: new Date().toISOString(),
        lastLoginAt: new Date().toISOString(),
      };
    } else {
      // Demo authentication
      await new Promise((r) => setTimeout(r, 600));
      const user: UserProfile = {
        uid: 'demo-' + Date.now().toString(36),
        email,
        displayName: email.split('@')[0],
        photoURL: `https://api.dicebear.com/7.x/bottts/svg?seed=${email}`,
        isAnonymous: false,
        createdAt: new Date().toISOString(),
        lastLoginAt: new Date().toISOString(),
      };
      localStorage.setItem(MOCK_USER_KEY, JSON.stringify(user));
      window.dispatchEvent(new Event('storage'));
      return user;
    }
  },

  async registerWithEmail(email: string, pass: string, displayName?: string): Promise<UserProfile> {
    if (auth) {
      const cred = await createUserWithEmailAndPassword(auth, email, pass);
      return {
        uid: cred.user.uid,
        email: cred.user.email,
        displayName: displayName || email.split('@')[0],
        photoURL: `https://api.dicebear.com/7.x/bottts/svg?seed=${cred.user.uid}`,
        isAnonymous: false,
        createdAt: new Date().toISOString(),
        lastLoginAt: new Date().toISOString(),
      };
    } else {
      await new Promise((r) => setTimeout(r, 600));
      const user: UserProfile = {
        uid: 'demo-reg-' + Date.now().toString(36),
        email,
        displayName: displayName || email.split('@')[0],
        photoURL: `https://api.dicebear.com/7.x/bottts/svg?seed=${email}`,
        isAnonymous: false,
        createdAt: new Date().toISOString(),
        lastLoginAt: new Date().toISOString(),
      };
      localStorage.setItem(MOCK_USER_KEY, JSON.stringify(user));
      window.dispatchEvent(new Event('storage'));
      return user;
    }
  },

  async loginAnonymously(): Promise<UserProfile> {
    if (auth) {
      const cred = await firebaseSignInAnonymously(auth);
      return {
        uid: cred.user.uid,
        email: null,
        displayName: 'Guest Operator ' + cred.user.uid.slice(0, 4).toUpperCase(),
        photoURL: `https://api.dicebear.com/7.x/bottts/svg?seed=${cred.user.uid}`,
        isAnonymous: true,
        createdAt: new Date().toISOString(),
        lastLoginAt: new Date().toISOString(),
      };
    } else {
      await new Promise((r) => setTimeout(r, 400));
      const guestId = Math.random().toString(36).slice(2, 7).toUpperCase();
      const user: UserProfile = {
        uid: 'guest-' + Date.now(),
        email: null,
        displayName: `Guest Operator ${guestId}`,
        photoURL: `https://api.dicebear.com/7.x/bottts/svg?seed=guest-${guestId}`,
        isAnonymous: true,
        createdAt: new Date().toISOString(),
        lastLoginAt: new Date().toISOString(),
      };
      localStorage.setItem(MOCK_USER_KEY, JSON.stringify(user));
      window.dispatchEvent(new Event('storage'));
      return user;
    }
  },

  async loginWithGoogle(): Promise<UserProfile> {
    if (auth) {
      const provider = new GoogleAuthProvider();
      const cred = await signInWithPopup(auth, provider);
      return {
        uid: cred.user.uid,
        email: cred.user.email,
        displayName: cred.user.displayName || 'Google User',
        photoURL: cred.user.photoURL,
        isAnonymous: false,
        createdAt: new Date().toISOString(),
        lastLoginAt: new Date().toISOString(),
      };
    } else {
      return this.registerWithEmail('google.user@dukku9x.io', 'password', 'Google Developer');
    }
  },

  async logout(): Promise<void> {
    if (auth) {
      await firebaseSignOut(auth);
    } else {
      localStorage.removeItem(MOCK_USER_KEY);
      window.dispatchEvent(new Event('storage'));
    }
  },
};

// --- FIRESTORE DATA SERVICES ---
export const firestoreService = {
  async getItems(): Promise<FirestoreDemoItem[]> {
    if (db) {
      try {
        const q = query(collection(db, 'dukku_items'), orderBy('createdAt', 'desc'), limit(20));
        const snapshot = await getDocs(q);
        return snapshot.docs.map((d) => ({
          id: d.id,
          ...d.data(),
        })) as FirestoreDemoItem[];
      } catch (err) {
        console.warn('Firestore fetch failed, falling back:', err);
        return getLocalItems();
      }
    }
    return getLocalItems();
  },

  async addItem(title: string, category: string, createdBy: string, isGuestItem = false): Promise<FirestoreDemoItem> {
    const newItemData = {
      title,
      category,
      createdAt: new Date().toISOString(),
      createdBy,
      isGuestItem,
    };

    if (db) {
      try {
        const docRef = await addDoc(collection(db, 'dukku_items'), newItemData);
        return {
          id: docRef.id,
          ...newItemData,
        };
      } catch (err) {
        console.warn('Firestore write failed, saving locally:', err);
      }
    }

    const items = getLocalItems();
    const newItem: FirestoreDemoItem = {
      id: 'item-' + Date.now(),
      ...newItemData,
    };
    items.unshift(newItem);
    saveLocalItems(items);
    return newItem;
  },

  async deleteItem(id: string): Promise<void> {
    if (db) {
      try {
        await deleteDoc(doc(db, 'dukku_items', id));
      } catch (err) {
        console.warn('Firestore delete failed:', err);
      }
    }
    const items = getLocalItems().filter((item) => item.id !== id);
    saveLocalItems(items);
  },
};

// --- STORAGE SERVICES ---
export const storageService = {
  async getFiles(): Promise<StorageDemoFile[]> {
    return getLocalStorageFiles();
  },

  async uploadFile(file: File, uploadedBy: string): Promise<StorageDemoFile> {
    let downloadUrl = '';

    if (storage) {
      try {
        const fileRef = ref(storage, `dukku_uploads/${Date.now()}_${file.name}`);
        const snapshot = await uploadBytes(fileRef, file);
        downloadUrl = await getDownloadURL(snapshot.ref);
      } catch (err) {
        console.warn('Storage upload error, using object URL fallback:', err);
        downloadUrl = URL.createObjectURL(file);
      }
    } else {
      downloadUrl = URL.createObjectURL(file);
    }

    const newFile: StorageDemoFile = {
      id: 'file-' + Date.now(),
      name: file.name,
      size: file.size,
      type: file.type || 'application/octet-stream',
      url: downloadUrl,
      uploadedAt: new Date().toISOString(),
      uploadedBy,
    };

    const files = getLocalStorageFiles();
    files.unshift(newFile);
    saveLocalStorageFiles(files);
    return newFile;
  },
};
