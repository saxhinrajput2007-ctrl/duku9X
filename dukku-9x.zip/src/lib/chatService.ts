import {
  collection,
  doc,
  setDoc,
  getDoc,
  getDocs,
  updateDoc,
  deleteDoc,
  addDoc,
  query,
  where,
  orderBy,
  onSnapshot,
  serverTimestamp,
  Unsubscribe
} from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, storage } from './firebase';
import { ChatMessage, ChatSession, QueueUser, UserProfile } from '../types';

// Storage key for blocked users in local storage
const BLOCKED_USERS_KEY = 'dukku9x_blocked_users';

export const getBlockedUsers = (): string[] => {
  try {
    const data = localStorage.getItem(BLOCKED_USERS_KEY);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
};

export const addBlockedUser = (targetUid: string) => {
  const current = getBlockedUsers();
  if (!current.includes(targetUid)) {
    current.push(targetUid);
    localStorage.setItem(BLOCKED_USERS_KEY, JSON.stringify(current));
  }
};

// Fun random anonymous stranger names and avatars for simulation fallback
const STRANGER_BOT_NAMES = [
  'Nebula Voyager',
  'Cyber Starlight',
  'Quantum Echo',
  'Solar Drift',
  'Pixel Wanderer',
  'Midnight Phantom',
  'Nova Spark',
  'Astra Nomad'
];

const STRANGER_REPLIES = [
  "Hey there! What's up in your world tonight?",
  "Greetings stranger! Fun finding another soul on Dukku 9X.",
  "Hello! Just trying out this random chat app. Pretty fast theme!",
  "Haha nice! Where are you connecting from?",
  "That's awesome! I love the dark purple aesthetic of this app.",
  "Totally agree! Firebase real-time database is super quick.",
  "Nice photo! Thanks for sharing.",
  "Cool! Let's talk about tech, music, or life."
];

export const chatService = {
  // --- 1. Join Matchmaking Queue & Find Stranger ---
  async joinQueue(
    user: UserProfile,
    interestTag: string = 'General',
    onMatchFound: (chat: ChatSession) => void,
    onWaiting: () => void
  ): Promise<{ unsubscribe: () => void; cancelQueue: () => Promise<void> }> {
    const blockedList = getBlockedUsers();

    if (!db) {
      // Fallback local match generator
      onWaiting();
      const botName = STRANGER_BOT_NAMES[Math.floor(Math.random() * STRANGER_BOT_NAMES.length)];
      const botUid = 'bot_' + Math.random().toString(36).slice(2, 8);
      const mockChatId = 'chat_local_' + Date.now();

      const mockChat: ChatSession = {
        id: mockChatId,
        participants: [user.uid, botUid],
        participantDetails: {
          [user.uid]: {
            displayName: user.displayName || 'You',
            photoURL: user.photoURL || '',
            isAnonymous: user.isAnonymous
          },
          [botUid]: {
            displayName: botName,
            photoURL: `https://api.dicebear.com/7.x/bottts/svg?seed=${botUid}`,
            isAnonymous: true
          }
        },
        status: 'active',
        createdAt: new Date().toISOString(),
        interestTag
      };

      const timer = setTimeout(() => {
        onMatchFound(mockChat);
      }, 1500);

      return {
        unsubscribe: () => clearTimeout(timer),
        cancelQueue: async () => clearTimeout(timer)
      };
    }

    try {
      // Check for available strangers waiting in Firestore
      const queueRef = collection(db, 'match_queue');
      const q = query(queueRef, where('status', '==', 'waiting'));
      const snapshot = await getDocs(q);

      let availablePartner: QueueUser | null = null;

      snapshot.docs.forEach((docSnap) => {
        const data = docSnap.data() as QueueUser;
        if (data.uid !== user.uid && !blockedList.includes(data.uid)) {
          availablePartner = data;
        }
      });

      if (availablePartner) {
        // MATCH FOUND! Create a new chat session doc
        const partner = availablePartner as QueueUser;
        const newChatId = `chat_${user.uid}_${partner.uid}_${Date.now()}`;

        const newChat: ChatSession = {
          id: newChatId,
          participants: [user.uid, partner.uid],
          participantDetails: {
            [user.uid]: {
              displayName: user.displayName || (user.isAnonymous ? 'Anonymous' : 'Operator'),
              photoURL: user.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${user.uid}`,
              isAnonymous: user.isAnonymous
            },
            [partner.uid]: {
              displayName: partner.displayName || 'Anonymous Stranger',
              photoURL: partner.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${partner.uid}`,
              isAnonymous: partner.isAnonymous
            }
          },
          status: 'active',
          createdAt: new Date().toISOString(),
          interestTag,
          typing: {
            [user.uid]: false,
            [partner.uid]: false
          }
        };

        // Create Chat document
        await setDoc(doc(db, 'chats', newChatId), newChat);

        // Add System Greeting Message
        await addDoc(collection(db, 'chats', newChatId, 'messages'), {
          chatId: newChatId,
          senderId: 'system',
          senderName: 'Dukku 9X System',
          text: `👋 Connected with a random stranger! Topic: #${interestTag}. Say hello!`,
          type: 'system',
          createdAt: new Date().toISOString()
        });

        // Delete partner from queue and update user state
        try {
          await deleteDoc(doc(db, 'match_queue', partner.uid));
        } catch (e) {
          console.warn('Queue cleanup error:', e);
        }

        onMatchFound(newChat);

        return {
          unsubscribe: () => {},
          cancelQueue: async () => {}
        };
      } else {
        // NO IMMEDIATE STRANGER FOUND -> Add current user to queue and listen for incoming matches
        const myQueueRef = doc(db, 'match_queue', user.uid);
        const queueData: QueueUser = {
          uid: user.uid,
          displayName: user.displayName || (user.isAnonymous ? 'Anonymous Guest' : 'Operator'),
          photoURL: user.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${user.uid}`,
          isAnonymous: user.isAnonymous,
          joinedAt: new Date().toISOString(),
          status: 'waiting',
          interestTag,
          blockedUsers: blockedList
        };

        await setDoc(myQueueRef, queueData);
        onWaiting();

        let botTimeout: NodeJS.Timeout | null = null;

        // Listen for chats where user is participant
        const chatsRef = collection(db, 'chats');
        const activeChatQuery = query(
          chatsRef,
          where('participants', 'array-contains', user.uid),
          where('status', '==', 'active')
        );

        const unsubChats = onSnapshot(activeChatQuery, (chatSnap) => {
          if (!chatSnap.empty) {
            // Found matched chat created by another user!
            const matchedDoc = chatSnap.docs[0];
            const chatData = matchedDoc.data() as ChatSession;
            chatData.id = matchedDoc.id;

            // Remove self from match queue
            deleteDoc(myQueueRef).catch(console.error);
            if (botTimeout) clearTimeout(botTimeout);

            onMatchFound(chatData);
          }
        });

        // If no real user arrives within 3.5 seconds, auto-match with a dynamic Stranger Bot so chat is instantly interactive!
        botTimeout = setTimeout(async () => {
          try {
            const botName = STRANGER_BOT_NAMES[Math.floor(Math.random() * STRANGER_BOT_NAMES.length)];
            const botUid = 'bot_' + Math.random().toString(36).slice(2, 8);
            const botChatId = `chat_${user.uid}_${botUid}_${Date.now()}`;

            const botChat: ChatSession = {
              id: botChatId,
              participants: [user.uid, botUid],
              participantDetails: {
                [user.uid]: {
                  displayName: user.displayName || 'You',
                  photoURL: user.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${user.uid}`,
                  isAnonymous: user.isAnonymous
                },
                [botUid]: {
                  displayName: botName,
                  photoURL: `https://api.dicebear.com/7.x/bottts/svg?seed=${botUid}`,
                  isAnonymous: true
                }
              },
              status: 'active',
              createdAt: new Date().toISOString(),
              interestTag,
              typing: {
                [user.uid]: false,
                [botUid]: false
              }
            };

            await setDoc(doc(db, 'chats', botChatId), botChat);
            await addDoc(collection(db, 'chats', botChatId, 'messages'), {
              chatId: botChatId,
              senderId: 'system',
              senderName: 'Dukku 9X System',
              text: `⚡ Matched with stranger "${botName}" (#${interestTag}). Both users are online.`,
              type: 'system',
              createdAt: new Date().toISOString()
            });

            await deleteDoc(myQueueRef).catch(() => {});
            onMatchFound(botChat);
          } catch (e) {
            console.error('Bot fallback error:', e);
          }
        }, 3500);

        const cancelQueue = async () => {
          if (botTimeout) clearTimeout(botTimeout);
          unsubChats();
          try {
            await deleteDoc(myQueueRef);
          } catch (e) {
            console.warn(e);
          }
        };

        return {
          unsubscribe: () => {
            if (botTimeout) clearTimeout(botTimeout);
            unsubChats();
          },
          cancelQueue
        };
      }
    } catch (error) {
      console.error('Matchmaking error:', error);
      onWaiting();
      return {
        unsubscribe: () => {},
        cancelQueue: async () => {}
      };
    }
  },

  // --- 2. Listen to Chat Document State (Ended / Typing / Status) ---
  listenToChatSession(chatId: string, callback: (chat: ChatSession) => void): Unsubscribe {
    if (!db) {
      return () => {};
    }
    const chatDocRef = doc(db, 'chats', chatId);
    return onSnapshot(chatDocRef, (docSnap) => {
      if (docSnap.exists()) {
        callback({ id: docSnap.id, ...docSnap.data() } as ChatSession);
      }
    });
  },

  // --- 3. Listen to Messages in Real-time ---
  listenToMessages(chatId: string, callback: (messages: ChatMessage[]) => void): Unsubscribe {
    if (!db) {
      return () => {};
    }

    const messagesRef = collection(db, 'chats', chatId, 'messages');
    const q = query(messagesRef, orderBy('createdAt', 'asc'));

    return onSnapshot(q, (snapshot) => {
      const msgs: ChatMessage[] = snapshot.docs.map((d) => ({
        id: d.id,
        ...d.data()
      })) as ChatMessage[];
      callback(msgs);
    });
  },

  // --- 4. Send Message (Text) ---
  async sendMessage(
    chatId: string,
    senderId: string,
    senderName: string,
    text: string,
    partnerUid?: string
  ): Promise<void> {
    if (!text.trim()) return;

    if (db) {
      const messagesRef = collection(db, 'chats', chatId, 'messages');
      await addDoc(messagesRef, {
        chatId,
        senderId,
        senderName,
        text: text.trim(),
        type: 'text',
        createdAt: new Date().toISOString()
      });

      // Update last message on chat
      await updateDoc(doc(db, 'chats', chatId), {
        lastMessage: text.trim(),
        lastMessageAt: new Date().toISOString(),
        [`typing.${senderId}`]: false
      });
    }

    // Bot Response trigger if partner is a simulated bot
    if (partnerUid?.startsWith('bot_')) {
      setTimeout(async () => {
        if (!db) return;
        // Set typing indicator
        await updateDoc(doc(db, 'chats', chatId), {
          [`typing.${partnerUid}`]: true
        });

        setTimeout(async () => {
          const randomReply = STRANGER_REPLIES[Math.floor(Math.random() * STRANGER_REPLIES.length)];
          await addDoc(collection(db, 'chats', chatId, 'messages'), {
            chatId,
            senderId: partnerUid,
            senderName: 'Stranger',
            text: randomReply,
            type: 'text',
            createdAt: new Date().toISOString()
          });

          await updateDoc(doc(db, 'chats', chatId), {
            lastMessage: randomReply,
            lastMessageAt: new Date().toISOString(),
            [`typing.${partnerUid}`]: false
          });
        }, 1200);
      }, 600);
    }
  },

  // --- 5. Send Image Attachment via Firebase Storage ---
  async sendImageMessage(
    chatId: string,
    senderId: string,
    senderName: string,
    file: File
  ): Promise<void> {
    let downloadUrl = '';

    if (storage) {
      try {
        const imageRef = ref(storage, `dukku_chat_images/${chatId}/${Date.now()}_${file.name}`);
        const snap = await uploadBytes(imageRef, file);
        downloadUrl = await getDownloadURL(snap.ref);
      } catch (e) {
        console.warn('Storage image upload fallback to Object URL:', e);
        downloadUrl = URL.createObjectURL(file);
      }
    } else {
      downloadUrl = URL.createObjectURL(file);
    }

    if (db) {
      const messagesRef = collection(db, 'chats', chatId, 'messages');
      await addDoc(messagesRef, {
        chatId,
        senderId,
        senderName,
        text: '📷 Sent an image attachment',
        imageUrl: downloadUrl,
        type: 'image',
        createdAt: new Date().toISOString()
      });

      await updateDoc(doc(db, 'chats', chatId), {
        lastMessage: '📷 Photo',
        lastMessageAt: new Date().toISOString()
      });
    }
  },

  // --- 6. Set Typing Indicator State ---
  async setTyping(chatId: string, userId: string, isTyping: boolean) {
    if (!db || !chatId) return;
    try {
      await updateDoc(doc(db, 'chats', chatId), {
        [`typing.${userId}`]: isTyping
      });
    } catch (e) {
      console.warn('Typing update failed:', e);
    }
  },

  // --- 7. Skip Partner / Leave Chat ---
  async skipPartner(chatId: string, userId: string): Promise<void> {
    if (db && chatId) {
      try {
        // Mark chat ended
        await updateDoc(doc(db, 'chats', chatId), {
          status: 'ended',
          endedBy: userId
        });

        // Post system alert
        await addDoc(collection(db, 'chats', chatId, 'messages'), {
          chatId,
          senderId: 'system',
          senderName: 'Dukku 9X System',
          text: '⚠️ Your stranger partner left or skipped the chat.',
          type: 'system',
          createdAt: new Date().toISOString()
        });
      } catch (e) {
        console.warn('Skip partner error:', e);
      }
    }
  },

  // --- 8. Report & Block Partner ---
  async reportAndBlock(chatId: string, reporterUid: string, reportedUid: string, reason: string): Promise<void> {
    addBlockedUser(reportedUid);

    if (db) {
      try {
        await addDoc(collection(db, 'reports'), {
          chatId,
          reporterUid,
          reportedUid,
          reason,
          createdAt: new Date().toISOString()
        });

        await this.skipPartner(chatId, reporterUid);
      } catch (e) {
        console.warn('Report failed:', e);
      }
    }
  }
};
